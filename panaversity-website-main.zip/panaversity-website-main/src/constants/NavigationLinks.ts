export const NavigationList = [
  { name: 'HOME', href: '/' },
  { name: 'OUR TEAM', href: '/our-team' },
  { name: 'RESULT', href: '/result' },
  { name: 'COURSE CONTENT', href: '/course' },
  { name: 'ANNOUNCEMENTS', href: '/announcements' },
];
