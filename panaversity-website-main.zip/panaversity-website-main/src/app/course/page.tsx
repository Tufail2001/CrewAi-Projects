import { redirect } from 'next/navigation'

const Introduction = () => {
  redirect('/course/introduction')
}

export default Introduction
